'''
The main program that loads the serialized model
and uploads the status of field to cloud .

Copyright (C) 2019 Inserito Systems

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
'''



from utils import init_video,encode_video_frame,show_video
from utils import encode_image,show_image
from model import load,forward
from handshake import upload
import cv2
import argparse
import numpy as np
import datetime
from playsound import playsound

classes_dict=['non-harmful,harmful']


path_='harmful'
model_path='model.h5'
size=250
framerate=1
model=load(model_path)

def predict_feed(feed,style,write):
    video=init_video(feed)
    i=0
    prev=0
    while True:
        img=encode_video_frame(video,size,style)
        if i==framerate:
            i=0
            predict=forward(img,model)
            if np.max(predict)>=thresh and np.argmax(predict)!=0 :
               
               cv2.putText(img,'harmful: {}%'.format(np.round(np.max(predict)*100,decimals=2)), (3, 15), cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,0,255), 2)

               if write=='True':
                   cv2.imwrite('distracted/distraction_%s.jpg'% datetime.datetime.now().strftime('%H:%M:%S:'+'%d:%m:%Y'),img)
               if prev==0:
                   #upload(1)
                   prev=1
            else:
                #cv2.putText(img,'nonharmful: {}%'.format(np.round(np.max(predict)*100,decimals=2)), (3, 15), cv2.FONT_HERSHEY_SIMPLEX,0.5, 			(0,255,0), 2)
                if prev==1:
                   #upload(0)
                   prev=0
        img=cv2.resize(img,(500,500))
        show_video(img,video)
        i+=1

            
        

def predict_frame(frame,style):
    img_path=frame
    img=encode_image(img_path,size,style)
    predict= forward(img,model)
    img=cv2.resize(img,(480,640))
    show_image(img,classes_dict[np.argmax(predict)],frame)
    if np.max(predict)>=thresh:
        upload(1)
    else:
        upload(0)
    
            
def main(input_,file_,style,write):
    while True:
        text = raw_input("Press [Enter] to start  [h] for help !!")
        if text == "":
            print ("Launching Driver Monitoring Software!!")
            if input_=='0':
                predict_frame(file_,style)
            if input_=='1':
                predict_feed(file_,style,write)
            if input_ not in ['0','1'] or file_==None:
                print ('Incorrect input or file command!!! Retry!!!')
                exit()
        elif text=='q':
             print "Exiting!!"
             exit()
             break
 	elif text=='h':
             print "We are here to help you!! This software is an Computer Vision-powered tool to monitor driver distraction. Input should either be [0] for image and [1] for video. File for input is mandatory. Enter [r] for right handed driving and [l] for left handed.Press [Enter] to launch the program and [q] to quit "
	else:
             print "!!OOps!!invalid input!!!Press [h] for help"
    
parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("file")
parser.add_argument("save")

args = parser.parse_args()
input_=args.input
file_=args.file
style=None
write=args.save
#print (write)
thresh=0.7
#main(input_,file_)
if file_=='0':
   main(input_,0,style,write)
else:
   main(input_,file_,style,write)
#show_feed= args.show_feed
#lane=args.lane
#lane=str(lane)
