from keras.models import load_model
import numpy as np

def load(path):
    model=load_model(path)
    return model

def forward(sample,model):
    return model.predict(np.expand_dims(sample,axis=0))


                         
    
