import cv2
from matplotlib import pyplot as plt


def encode_image(path,size,style):
    try:
        x=cv2.imread(path)
        x=cv2.resize(x,(size,size))
        if style=='r':
           x=cv2.flip(x,1)
        return x
    except cv2.error:
        print 'Footage Error!! Check filename and directory structure'
        exit()
def init_video(feed):
    cap=cv2.VideoCapture(feed)
    return cap

def encode_video_frame(cap,size,style):
    ret,image=cap.read()
    if ret:
        x=cv2.resize(image,(size,size))
        if style=='r':
           x=cv2.flip(x,1)
        return x
    else:
        cap.release()
        print 'End of Footage or Footage Error!!!'
        exit()

def show_video(img,cap):
    cv2.imshow("Output", img)
    k=cv2.waitKey(2)
    if k==ord('q'):
        cv2.destroyAllWindows()
        cap.release()

def show_image(img,predicted,frame):
    plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
    plt.title('{}:{}'.format(frame,predicted))
    plt.show()

    
